import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import BasicExample from './exemple';
import GroupList from './groupMenu';
import Addtable from './addTabe';
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux'
import { updateTable } from '../slices/listTable'
function MainCpn() {
    const prAddtb = {
        heading: 'Nhóm bảng 1',
        nameTable: 'tb_1',
        nameTableview: 'new tb',
        numOfcol: 5
    }
    useEffect(() => {
        fetch('http://localhost:80')
            .then((response) => response.json())
            .then((data) => {
                dispatch(updateTable(data.post.table))
            });
    })
    const listTableValue = useSelector((state) => state.listTable.data)
    console.log("data___", listTableValue);
    const dispatch = useDispatch();
    // const menuData = [
    //     {
    //     heading: listTableValue[0].heading,
    //     list: listTableValue.map((item) => item.name_CollectionView)
    //     }
    //     ]
     const [nameTb, setNametb] = useState("Bang 1");

    const changeTable = (keyTable) => {
        setNametb(keyTable)
    }
    return (
        <Container>
            <Row>
                <Col xs={12} md={4} lg={2} >
                    <GroupList changeTable={changeTable} menuData={[
                        {heading:"Tb 1" ,list: ["bang 1","Bang 2","Bang 3"] },
                        {heading:"Tb 1" ,list: ["bang 1","Bang 2","Bang 3"] },
                        {heading:"Tb 1" ,list: ["bang 1","Bang 2","Bang 3"] }
                    ]}></GroupList>
                    <Addtable addTable={prAddtb} ></Addtable>  {/*callbackFnc = {setStateAddtb}*/}
                </Col>
                <Col xs={12} md={8} lg={10}>
                    <BasicExample title={nameTb}></BasicExample>
                </Col>
            </Row>
        </Container>



    )
}
export default MainCpn;