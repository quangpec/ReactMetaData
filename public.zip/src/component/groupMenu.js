import React, { useState } from 'react';
import ListGroup from 'react-bootstrap/ListGroup';

function Childmenu(props) {
  const heading = props.heading;
  const list = props.list;
  const [show, setShow] = useState(false);
  const handledShow = () => {
    setShow(!show)
  }
  const handledTable =(e)=>{
    props.changeTable(e.target.innerHTML)
  }
  return (
    <>
        <ListGroup.Item as="li" active  onClick={handledShow} style ={{textAlign : "left", borderBlockColor:"#fff"}}>
          {heading}
        </ListGroup.Item>
      {list.map((l, i) =>
        show ? <ListGroup.Item as="li" value= {i} key={i} onClick ={handledTable}>{l} </ListGroup.Item> : null
      )}

    </>
  )
}

function GroupList(props) {
  const menuList = props.menuData;

  return (
    <ListGroup as="ul">
      {/* <ListGroup.Item as="li" active>
        List Table
      </ListGroup.Item> */}
      {menuList.map((e,i) => <Childmenu heading={e.heading} list={e.list} changeTable ={props.changeTable} key ={i}></Childmenu>)}
    </ListGroup>
  );

}

export default GroupList;