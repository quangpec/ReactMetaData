import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import React, { useState, useEffect } from 'react';

function Rowtable  (props) {
  const e = props.e;
  return(
    <tr>
      {e.map((e,i) =><td key = {i}>{e}</td>)}
    </tr>
  )
}
function TableCpn(props) {
  const [data, setData] = useState(props.data);
  const [heading, setHeading] = useState(props.heading);
  const  handelClick =() =>{
    setHeading(
    heading.concat('thêm mới')
  )}
  const arr = ['','','',''];
  const newRow = ()=>{
    setData(
      data.concat([arr])
    )
  }
  return (
    <>
      <h2>{props.title}</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            {heading.map((head,i) => <th key = {i}>{head}</th>)}
          </tr>
        </thead>
        <tbody>
        {data.map((d,i) =><Rowtable e = {d} key ={i}/>
        )}
        </tbody>
      </Table>
      <Button variant="outline-primary" onClick={handelClick}>Add new Col</Button>{' '}
      <Button variant="outline-primary" onClick={newRow}>Add new row</Button>{' '}
    </>
  )

}

function BasicExample(props) {
  const title = ['STT', 'Name', 'Email', 'địa chỉ'];
  const data =  [['2','2','3','4'],['4','5','5','5']];
  return (
    <TableCpn heading={title} data = {data} title ={props.title} ></TableCpn>
  );
}

export default BasicExample;