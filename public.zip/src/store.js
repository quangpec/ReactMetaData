import { configureStore } from '@reduxjs/toolkit'
import listTableReducer from './slices/listTable';

export const store = configureStore({
  reducer: {
    listTable: listTableReducer
  },
})
