import MainCpn from './component/mainComponent'
import './App.css';
function App() {
  return (
    <div className="App">
      <div className='mt-5'>
        {/* <div style = {{margin: '100px'}}> </div> */}
      <MainCpn></MainCpn>
      </div>
    </div>
  );
}

export default App;
